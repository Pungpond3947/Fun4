// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from robot_interfaces:srv/ControllerData.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACES__SRV__DETAIL__CONTROLLER_DATA__BUILDER_HPP_
#define ROBOT_INTERFACES__SRV__DETAIL__CONTROLLER_DATA__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "robot_interfaces/srv/detail/controller_data__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace robot_interfaces
{

namespace srv
{

namespace builder
{

class Init_ControllerData_Request_orientation
{
public:
  explicit Init_ControllerData_Request_orientation(::robot_interfaces::srv::ControllerData_Request & msg)
  : msg_(msg)
  {}
  ::robot_interfaces::srv::ControllerData_Request orientation(::robot_interfaces::srv::ControllerData_Request::_orientation_type arg)
  {
    msg_.orientation = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::srv::ControllerData_Request msg_;
};

class Init_ControllerData_Request_position
{
public:
  explicit Init_ControllerData_Request_position(::robot_interfaces::srv::ControllerData_Request & msg)
  : msg_(msg)
  {}
  Init_ControllerData_Request_orientation position(::robot_interfaces::srv::ControllerData_Request::_position_type arg)
  {
    msg_.position = std::move(arg);
    return Init_ControllerData_Request_orientation(msg_);
  }

private:
  ::robot_interfaces::srv::ControllerData_Request msg_;
};

class Init_ControllerData_Request_mode
{
public:
  Init_ControllerData_Request_mode()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ControllerData_Request_position mode(::robot_interfaces::srv::ControllerData_Request::_mode_type arg)
  {
    msg_.mode = std::move(arg);
    return Init_ControllerData_Request_position(msg_);
  }

private:
  ::robot_interfaces::srv::ControllerData_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::srv::ControllerData_Request>()
{
  return robot_interfaces::srv::builder::Init_ControllerData_Request_mode();
}

}  // namespace robot_interfaces


namespace robot_interfaces
{

namespace srv
{

namespace builder
{

class Init_ControllerData_Response_inprogress
{
public:
  Init_ControllerData_Response_inprogress()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::robot_interfaces::srv::ControllerData_Response inprogress(::robot_interfaces::srv::ControllerData_Response::_inprogress_type arg)
  {
    msg_.inprogress = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::srv::ControllerData_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::srv::ControllerData_Response>()
{
  return robot_interfaces::srv::builder::Init_ControllerData_Response_inprogress();
}

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__SRV__DETAIL__CONTROLLER_DATA__BUILDER_HPP_
