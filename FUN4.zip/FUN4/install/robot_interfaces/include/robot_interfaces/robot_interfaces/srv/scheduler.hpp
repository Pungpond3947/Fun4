// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACES__SRV__SCHEDULER_HPP_
#define ROBOT_INTERFACES__SRV__SCHEDULER_HPP_

#include "robot_interfaces/srv/detail/scheduler__struct.hpp"
#include "robot_interfaces/srv/detail/scheduler__builder.hpp"
#include "robot_interfaces/srv/detail/scheduler__traits.hpp"
#include "robot_interfaces/srv/detail/scheduler__type_support.hpp"

#endif  // ROBOT_INTERFACES__SRV__SCHEDULER_HPP_
