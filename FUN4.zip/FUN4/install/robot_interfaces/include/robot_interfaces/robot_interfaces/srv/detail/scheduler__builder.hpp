// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from robot_interfaces:srv/Scheduler.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACES__SRV__DETAIL__SCHEDULER__BUILDER_HPP_
#define ROBOT_INTERFACES__SRV__DETAIL__SCHEDULER__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "robot_interfaces/srv/detail/scheduler__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace robot_interfaces
{

namespace srv
{

namespace builder
{

class Init_Scheduler_Request_position
{
public:
  explicit Init_Scheduler_Request_position(::robot_interfaces::srv::Scheduler_Request & msg)
  : msg_(msg)
  {}
  ::robot_interfaces::srv::Scheduler_Request position(::robot_interfaces::srv::Scheduler_Request::_position_type arg)
  {
    msg_.position = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::srv::Scheduler_Request msg_;
};

class Init_Scheduler_Request_button
{
public:
  explicit Init_Scheduler_Request_button(::robot_interfaces::srv::Scheduler_Request & msg)
  : msg_(msg)
  {}
  Init_Scheduler_Request_position button(::robot_interfaces::srv::Scheduler_Request::_button_type arg)
  {
    msg_.button = std::move(arg);
    return Init_Scheduler_Request_position(msg_);
  }

private:
  ::robot_interfaces::srv::Scheduler_Request msg_;
};

class Init_Scheduler_Request_state
{
public:
  Init_Scheduler_Request_state()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Scheduler_Request_button state(::robot_interfaces::srv::Scheduler_Request::_state_type arg)
  {
    msg_.state = std::move(arg);
    return Init_Scheduler_Request_button(msg_);
  }

private:
  ::robot_interfaces::srv::Scheduler_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::srv::Scheduler_Request>()
{
  return robot_interfaces::srv::builder::Init_Scheduler_Request_state();
}

}  // namespace robot_interfaces


namespace robot_interfaces
{

namespace srv
{

namespace builder
{

class Init_Scheduler_Response_mode_readback
{
public:
  explicit Init_Scheduler_Response_mode_readback(::robot_interfaces::srv::Scheduler_Response & msg)
  : msg_(msg)
  {}
  ::robot_interfaces::srv::Scheduler_Response mode_readback(::robot_interfaces::srv::Scheduler_Response::_mode_readback_type arg)
  {
    msg_.mode_readback = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::srv::Scheduler_Response msg_;
};

class Init_Scheduler_Response_inprogress
{
public:
  Init_Scheduler_Response_inprogress()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_Scheduler_Response_mode_readback inprogress(::robot_interfaces::srv::Scheduler_Response::_inprogress_type arg)
  {
    msg_.inprogress = std::move(arg);
    return Init_Scheduler_Response_mode_readback(msg_);
  }

private:
  ::robot_interfaces::srv::Scheduler_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::srv::Scheduler_Response>()
{
  return robot_interfaces::srv::builder::Init_Scheduler_Response_inprogress();
}

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__SRV__DETAIL__SCHEDULER__BUILDER_HPP_
