// generated from rosidl_generator_c/resource/idl.h.em
// with input from robot_interfaces:srv/RandomEndeffector.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACES__SRV__RANDOM_ENDEFFECTOR_H_
#define ROBOT_INTERFACES__SRV__RANDOM_ENDEFFECTOR_H_

#include "robot_interfaces/srv/detail/random_endeffector__struct.h"
#include "robot_interfaces/srv/detail/random_endeffector__functions.h"
#include "robot_interfaces/srv/detail/random_endeffector__type_support.h"

#endif  // ROBOT_INTERFACES__SRV__RANDOM_ENDEFFECTOR_H_
