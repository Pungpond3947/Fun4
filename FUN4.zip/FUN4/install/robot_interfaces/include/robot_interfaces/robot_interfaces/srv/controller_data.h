// generated from rosidl_generator_c/resource/idl.h.em
// with input from robot_interfaces:srv/ControllerData.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACES__SRV__CONTROLLER_DATA_H_
#define ROBOT_INTERFACES__SRV__CONTROLLER_DATA_H_

#include "robot_interfaces/srv/detail/controller_data__struct.h"
#include "robot_interfaces/srv/detail/controller_data__functions.h"
#include "robot_interfaces/srv/detail/controller_data__type_support.h"

#endif  // ROBOT_INTERFACES__SRV__CONTROLLER_DATA_H_
