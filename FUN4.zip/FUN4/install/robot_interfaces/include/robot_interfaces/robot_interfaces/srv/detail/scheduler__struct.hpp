// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from robot_interfaces:srv/Scheduler.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACES__SRV__DETAIL__SCHEDULER__STRUCT_HPP_
#define ROBOT_INTERFACES__SRV__DETAIL__SCHEDULER__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'state'
// Member 'button'
#include "std_msgs/msg/detail/string__struct.hpp"
// Member 'position'
#include "geometry_msgs/msg/detail/point__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__robot_interfaces__srv__Scheduler_Request __attribute__((deprecated))
#else
# define DEPRECATED__robot_interfaces__srv__Scheduler_Request __declspec(deprecated)
#endif

namespace robot_interfaces
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct Scheduler_Request_
{
  using Type = Scheduler_Request_<ContainerAllocator>;

  explicit Scheduler_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : state(_init),
    button(_init),
    position(_init)
  {
    (void)_init;
  }

  explicit Scheduler_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : state(_alloc, _init),
    button(_alloc, _init),
    position(_alloc, _init)
  {
    (void)_init;
  }

  // field types and members
  using _state_type =
    std_msgs::msg::String_<ContainerAllocator>;
  _state_type state;
  using _button_type =
    std_msgs::msg::String_<ContainerAllocator>;
  _button_type button;
  using _position_type =
    geometry_msgs::msg::Point_<ContainerAllocator>;
  _position_type position;

  // setters for named parameter idiom
  Type & set__state(
    const std_msgs::msg::String_<ContainerAllocator> & _arg)
  {
    this->state = _arg;
    return *this;
  }
  Type & set__button(
    const std_msgs::msg::String_<ContainerAllocator> & _arg)
  {
    this->button = _arg;
    return *this;
  }
  Type & set__position(
    const geometry_msgs::msg::Point_<ContainerAllocator> & _arg)
  {
    this->position = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    robot_interfaces::srv::Scheduler_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const robot_interfaces::srv::Scheduler_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<robot_interfaces::srv::Scheduler_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<robot_interfaces::srv::Scheduler_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::srv::Scheduler_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::srv::Scheduler_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::srv::Scheduler_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::srv::Scheduler_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<robot_interfaces::srv::Scheduler_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<robot_interfaces::srv::Scheduler_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__robot_interfaces__srv__Scheduler_Request
    std::shared_ptr<robot_interfaces::srv::Scheduler_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__robot_interfaces__srv__Scheduler_Request
    std::shared_ptr<robot_interfaces::srv::Scheduler_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const Scheduler_Request_ & other) const
  {
    if (this->state != other.state) {
      return false;
    }
    if (this->button != other.button) {
      return false;
    }
    if (this->position != other.position) {
      return false;
    }
    return true;
  }
  bool operator!=(const Scheduler_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct Scheduler_Request_

// alias to use template instance with default allocator
using Scheduler_Request =
  robot_interfaces::srv::Scheduler_Request_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace robot_interfaces


// Include directives for member types
// Member 'mode_readback'
// already included above
// #include "std_msgs/msg/detail/string__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__robot_interfaces__srv__Scheduler_Response __attribute__((deprecated))
#else
# define DEPRECATED__robot_interfaces__srv__Scheduler_Response __declspec(deprecated)
#endif

namespace robot_interfaces
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct Scheduler_Response_
{
  using Type = Scheduler_Response_<ContainerAllocator>;

  explicit Scheduler_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : mode_readback(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->inprogress = false;
    }
  }

  explicit Scheduler_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : mode_readback(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->inprogress = false;
    }
  }

  // field types and members
  using _inprogress_type =
    bool;
  _inprogress_type inprogress;
  using _mode_readback_type =
    std_msgs::msg::String_<ContainerAllocator>;
  _mode_readback_type mode_readback;

  // setters for named parameter idiom
  Type & set__inprogress(
    const bool & _arg)
  {
    this->inprogress = _arg;
    return *this;
  }
  Type & set__mode_readback(
    const std_msgs::msg::String_<ContainerAllocator> & _arg)
  {
    this->mode_readback = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    robot_interfaces::srv::Scheduler_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const robot_interfaces::srv::Scheduler_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<robot_interfaces::srv::Scheduler_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<robot_interfaces::srv::Scheduler_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::srv::Scheduler_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::srv::Scheduler_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      robot_interfaces::srv::Scheduler_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<robot_interfaces::srv::Scheduler_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<robot_interfaces::srv::Scheduler_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<robot_interfaces::srv::Scheduler_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__robot_interfaces__srv__Scheduler_Response
    std::shared_ptr<robot_interfaces::srv::Scheduler_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__robot_interfaces__srv__Scheduler_Response
    std::shared_ptr<robot_interfaces::srv::Scheduler_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const Scheduler_Response_ & other) const
  {
    if (this->inprogress != other.inprogress) {
      return false;
    }
    if (this->mode_readback != other.mode_readback) {
      return false;
    }
    return true;
  }
  bool operator!=(const Scheduler_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct Scheduler_Response_

// alias to use template instance with default allocator
using Scheduler_Response =
  robot_interfaces::srv::Scheduler_Response_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace robot_interfaces

namespace robot_interfaces
{

namespace srv
{

struct Scheduler
{
  using Request = robot_interfaces::srv::Scheduler_Request;
  using Response = robot_interfaces::srv::Scheduler_Response;
};

}  // namespace srv

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__SRV__DETAIL__SCHEDULER__STRUCT_HPP_
