// generated from rosidl_generator_c/resource/idl.h.em
// with input from robot_interfaces:srv/Scheduler.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACES__SRV__SCHEDULER_H_
#define ROBOT_INTERFACES__SRV__SCHEDULER_H_

#include "robot_interfaces/srv/detail/scheduler__struct.h"
#include "robot_interfaces/srv/detail/scheduler__functions.h"
#include "robot_interfaces/srv/detail/scheduler__type_support.h"

#endif  // ROBOT_INTERFACES__SRV__SCHEDULER_H_
