// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from robot_interfaces:srv/Scheduler.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACES__SRV__DETAIL__SCHEDULER__STRUCT_H_
#define ROBOT_INTERFACES__SRV__DETAIL__SCHEDULER__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'state'
// Member 'button'
#include "std_msgs/msg/detail/string__struct.h"
// Member 'position'
#include "geometry_msgs/msg/detail/point__struct.h"

/// Struct defined in srv/Scheduler in the package robot_interfaces.
typedef struct robot_interfaces__srv__Scheduler_Request
{
  std_msgs__msg__String state;
  std_msgs__msg__String button;
  geometry_msgs__msg__Point position;
} robot_interfaces__srv__Scheduler_Request;

// Struct for a sequence of robot_interfaces__srv__Scheduler_Request.
typedef struct robot_interfaces__srv__Scheduler_Request__Sequence
{
  robot_interfaces__srv__Scheduler_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} robot_interfaces__srv__Scheduler_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'mode_readback'
// already included above
// #include "std_msgs/msg/detail/string__struct.h"

/// Struct defined in srv/Scheduler in the package robot_interfaces.
typedef struct robot_interfaces__srv__Scheduler_Response
{
  bool inprogress;
  std_msgs__msg__String mode_readback;
} robot_interfaces__srv__Scheduler_Response;

// Struct for a sequence of robot_interfaces__srv__Scheduler_Response.
typedef struct robot_interfaces__srv__Scheduler_Response__Sequence
{
  robot_interfaces__srv__Scheduler_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} robot_interfaces__srv__Scheduler_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ROBOT_INTERFACES__SRV__DETAIL__SCHEDULER__STRUCT_H_
