// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from robot_interfaces:srv/RandomEndeffector.idl
// generated code does not contain a copyright notice

#ifndef ROBOT_INTERFACES__SRV__DETAIL__RANDOM_ENDEFFECTOR__BUILDER_HPP_
#define ROBOT_INTERFACES__SRV__DETAIL__RANDOM_ENDEFFECTOR__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "robot_interfaces/srv/detail/random_endeffector__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace robot_interfaces
{

namespace srv
{

namespace builder
{

class Init_RandomEndeffector_Request_mode
{
public:
  Init_RandomEndeffector_Request_mode()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::robot_interfaces::srv::RandomEndeffector_Request mode(::robot_interfaces::srv::RandomEndeffector_Request::_mode_type arg)
  {
    msg_.mode = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::srv::RandomEndeffector_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::srv::RandomEndeffector_Request>()
{
  return robot_interfaces::srv::builder::Init_RandomEndeffector_Request_mode();
}

}  // namespace robot_interfaces


namespace robot_interfaces
{

namespace srv
{

namespace builder
{

class Init_RandomEndeffector_Response_inprogress
{
public:
  explicit Init_RandomEndeffector_Response_inprogress(::robot_interfaces::srv::RandomEndeffector_Response & msg)
  : msg_(msg)
  {}
  ::robot_interfaces::srv::RandomEndeffector_Response inprogress(::robot_interfaces::srv::RandomEndeffector_Response::_inprogress_type arg)
  {
    msg_.inprogress = std::move(arg);
    return std::move(msg_);
  }

private:
  ::robot_interfaces::srv::RandomEndeffector_Response msg_;
};

class Init_RandomEndeffector_Response_orientation
{
public:
  explicit Init_RandomEndeffector_Response_orientation(::robot_interfaces::srv::RandomEndeffector_Response & msg)
  : msg_(msg)
  {}
  Init_RandomEndeffector_Response_inprogress orientation(::robot_interfaces::srv::RandomEndeffector_Response::_orientation_type arg)
  {
    msg_.orientation = std::move(arg);
    return Init_RandomEndeffector_Response_inprogress(msg_);
  }

private:
  ::robot_interfaces::srv::RandomEndeffector_Response msg_;
};

class Init_RandomEndeffector_Response_position
{
public:
  Init_RandomEndeffector_Response_position()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RandomEndeffector_Response_orientation position(::robot_interfaces::srv::RandomEndeffector_Response::_position_type arg)
  {
    msg_.position = std::move(arg);
    return Init_RandomEndeffector_Response_orientation(msg_);
  }

private:
  ::robot_interfaces::srv::RandomEndeffector_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::robot_interfaces::srv::RandomEndeffector_Response>()
{
  return robot_interfaces::srv::builder::Init_RandomEndeffector_Response_position();
}

}  // namespace robot_interfaces

#endif  // ROBOT_INTERFACES__SRV__DETAIL__RANDOM_ENDEFFECTOR__BUILDER_HPP_
